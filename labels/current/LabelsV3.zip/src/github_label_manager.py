import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import requests
import os
from PIL import Image, ImageTk
from io import BytesIO
import webbrowser
import json
import threading
from datetime import datetime
import subprocess
import shutil
import tempfile
import re

class GitHubLabelManager:
    def __init__(self, root):
        self.root = root
        self.root.title("Label Manager - Omar27522/Projects")
        self.root.geometry("1000x700")
        
        # Configure root background
        self.root.configure(bg='#ecf0f1')
        
        # Repository details
        self.repo_owner = "Omar27522"
        self.repo_name = "Projects"
        self.labels_path = "labels/files"
        self.repo_url = f"https://github.com/{self.repo_owner}/{self.repo_name}"
        
        # Local repository path
        self.local_repo_path = None
        
        # Initialize status bar with colors
        self.status_var = tk.StringVar()
        self.status_bar = tk.Label(root, textvariable=self.status_var, bd=1, 
                                 relief=tk.SUNKEN, anchor=tk.W,
                                 bg='#3498db', fg='white')  # Blue background with white text
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Initialize repository
        if not self.setup_repository():
            messagebox.showerror("Error", "Failed to initialize repository. Please ensure Git is installed.")
            root.destroy()
            return
        
        # Set window icon (GitHub icon)
        try:
            icon_url = "https://github.com/favicon.ico"
            icon_response = requests.get(icon_url)
            if icon_response.status_code == 200:
                icon_data = BytesIO(icon_response.content)
                icon_image = Image.open(icon_data)
                icon_photo = ImageTk.PhotoImage(icon_image)
                self.root.iconphoto(True, icon_photo)
        except:
            pass  # Ignore icon loading errors
        
        # Configure style
        style = ttk.Style()
        style.configure('Header.TLabel', 
                       font=('TkDefaultFont', 10, 'bold'),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        style.configure('FileCount.TLabel', 
                       font=('TkDefaultFont', 9),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        style.configure('Action.TButton', 
                       padding=5,
                       background='#3498db',
                       foreground='white')
        
        # Create main container with padding and background
        self.main_container = tk.Frame(root, bg='#ecf0f1', padx=10, pady=10)
        self.main_container.pack(fill=tk.BOTH, expand=True)
        
        # Create header frame
        self.create_header_frame()
        
        # Create main content frame
        self.content_frame = tk.Frame(self.main_container, bg='#ecf0f1')
        self.content_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Configure grid weights
        self.content_frame.grid_columnconfigure(0, weight=1)  # File list
        self.content_frame.grid_columnconfigure(1, weight=2)  # Preview
        
        # Create left panel (file list)
        self.create_file_list_panel()
        
        # Create right panel (preview)
        self.create_preview_panel()
        
        # Initialize variables
        self.current_image = None
        self.files_data = []
        self.last_refresh = None
        
        # Load initial data
        self.set_status("Loading repository files...")
        self.refresh_files()

    def create_header_frame(self):
        """Create the header frame with repository info and controls"""
        header_frame = tk.Frame(self.main_container, bg='#ecf0f1')
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Repository info
        info_frame = tk.Frame(header_frame, bg='#ecf0f1')
        info_frame.pack(side=tk.LEFT)
        
        repo_label = ttk.Label(info_frame, text="GitHub Repository:",
                             style='Header.TLabel')
        repo_label.pack(side=tk.LEFT)
        
        repo_link = tk.Label(info_frame, text=self.repo_url,
                         fg='#3498db', cursor='hand2',
                         bg='#ecf0f1')
        repo_link.pack(side=tk.LEFT, padx=5)
        repo_link.bind('<Button-1>', 
                      lambda e: webbrowser.open(self.repo_url))
        
        # Last refresh time
        self.refresh_label = tk.Label(info_frame, text="",
                                  bg='#ecf0f1', fg='#2c3e50')
        self.refresh_label.pack(side=tk.LEFT, padx=20)

    def create_file_list_panel(self):
        """Create the left panel with file list and search"""
        list_frame = tk.Frame(self.content_frame, bg='#ecf0f1')
        list_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        
        # Search frame
        search_frame = tk.Frame(list_frame, bg='#ecf0f1')
        search_frame.pack(fill=tk.X, pady=(0, 5))
        
        search_label = ttk.Label(search_frame, text="Search:",
                               style='Header.TLabel')
        search_label.pack(side=tk.LEFT)
        
        self.search_var = tk.StringVar()
        self.search_var.trace('w', self.filter_files)
        search_entry = tk.Entry(search_frame, textvariable=self.search_var,
                              bg='white', fg='#2c3e50')
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        # File count
        self.count_label = ttk.Label(search_frame, text="Files: 0",
                                   style='FileCount.TLabel')
        self.count_label.pack(side=tk.RIGHT)
        
        # Control buttons frame
        controls_frame = tk.Frame(list_frame, bg='#ecf0f1')
        controls_frame.pack(fill=tk.X, pady=5)
        
        # Big buttons with icons (using text as icons for now)
        button_height = 2
        button_width = 15
        
        refresh_btn = tk.Button(controls_frame, text="🔄 Refresh Files",
                            command=self.refresh_files,
                            bg='#3498db',
                            activebackground='#2980b9',
                            fg='white',
                            height=button_height,
                            width=button_width,
                            font=('TkDefaultFont', 10))
        refresh_btn.pack(side=tk.LEFT, padx=2)
        
        show_duplicates_btn = tk.Button(controls_frame, text="🔍 Find Duplicates",
                                    command=self.show_duplicates,
                                    bg='#e67e22',
                                    activebackground='#d35400',
                                    fg='white',
                                    height=button_height,
                                    width=button_width,
                                    font=('TkDefaultFont', 10))
        show_duplicates_btn.pack(side=tk.LEFT, padx=2)
        
        upload_btn = tk.Button(controls_frame, text="⬆️ Upload Labels",
                           command=self.upload_files,
                           bg='#2ecc71',
                           activebackground='#27ae60',
                           fg='white',
                           height=button_height,
                           width=button_width,
                           font=('TkDefaultFont', 10))
        upload_btn.pack(side=tk.LEFT, padx=2)
        
        delete_btn = tk.Button(controls_frame, text="❌ Delete Selected",
                           command=self.delete_files,
                           bg='#e74c3c',
                           activebackground='#c0392b',
                           fg='white',
                           height=button_height,
                           width=button_width,
                           font=('TkDefaultFont', 10))
        delete_btn.pack(side=tk.LEFT, padx=2)
        
        # Create listbox with scrollbar
        list_container = tk.Frame(list_frame, bg='#ecf0f1')
        list_container.pack(fill=tk.BOTH, expand=True)
        
        self.file_listbox = tk.Listbox(list_container, bg='white', fg='#2c3e50',
                                    selectmode=tk.EXTENDED,
                                    font=('TkDefaultFont', 10))
        self.file_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(list_container)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.file_listbox.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.file_listbox.yview)
        
        # Bind selection event
        self.file_listbox.bind('<<ListboxSelect>>', self.on_file_select)

    def create_preview_panel(self):
        """Create the right panel for file preview"""
        preview_frame = tk.Frame(self.content_frame, bg='#ecf0f1')
        preview_frame.grid(row=0, column=1, sticky="nsew")
        
        # Preview label
        self.preview_label = tk.Label(preview_frame, bg='#ecf0f1')
        self.preview_label.pack(fill=tk.BOTH, expand=True)
        
        # File info frame
        info_frame = tk.Frame(preview_frame, bg='#ecf0f1')
        info_frame.pack(fill=tk.X, pady=5)
        
        self.info_label = tk.Label(info_frame, text="", wraplength=400,
                               bg='#ecf0f1', fg='#2c3e50')
        self.info_label.pack(fill=tk.X)
        
        # Action buttons
        buttons_frame = tk.Frame(preview_frame, bg='#ecf0f1')
        buttons_frame.pack(fill=tk.X)
        
        # Download button with purple theme
        download_btn = tk.Button(buttons_frame, text="Download Labels",
                             command=self.download_labels,
                             bg='#9b59b6',  # Bright purple
                             activebackground='#8e44ad',  # Darker purple when clicked
                             fg='white',
                             relief='raised')
        download_btn.pack(side=tk.LEFT, padx=5)

    def set_status(self, message):
        """Update status bar message"""
        self.status_var.set(message)
        self.root.update_idletasks()

    def refresh_files(self):
        """Refresh the file list from GitHub"""
        try:
            self.set_status("Fetching repository files...")
            url = f"https://api.github.com/repos/{self.repo_owner}/{self.repo_name}/contents/{self.labels_path}"
            response = requests.get(url)
            
            if response.status_code != 200:
                raise Exception(f"Failed to fetch files: HTTP {response.status_code}")
            
            self.files_data = response.json()
            self.update_file_list()
            
            self.last_refresh = datetime.now()
            self.refresh_label.config(
                text=f"Last refresh: {self.last_refresh.strftime('%H:%M:%S')}")
            
            self.set_status(f"Found {len(self.files_data)} files in repository")
            
        except Exception as e:
            self.set_status(f"Error: {str(e)}")
            messagebox.showerror("Error", str(e))
    
    def update_file_list(self):
        """Update the listbox with files"""
        self.file_listbox.delete(0, tk.END)
        search_term = self.search_var.get().lower()
        
        displayed_files = []
        for file in self.files_data:
            if file['type'] == 'file' and file['name'].lower().endswith(('.png', '.jpg', '.jpeg')):
                if search_term in file['name'].lower():
                    displayed_files.append(file)
                    self.file_listbox.insert(tk.END, file['name'])
        
        self.count_label.config(text=f"Files: {len(displayed_files)}")
    
    def filter_files(self, *args):
        """Filter files based on search term"""
        self.update_file_list()
    
    def on_file_select(self, event):
        """Handle file selection"""
        if not self.file_listbox.curselection():
            self.preview_label.config(image='')
            self.info_label.config(text='')
            return
        
        selection = self.file_listbox.curselection()[0]
        file_name = self.file_listbox.get(selection)
        file_data = next((f for f in self.files_data if f['name'] == file_name), None)
        
        if not file_data:
            return
        
        try:
            # Load and display image
            response = requests.get(file_data['download_url'])
            if response.status_code != 200:
                raise Exception(f"Failed to fetch image: HTTP {response.status_code}")
            
            image = Image.open(BytesIO(response.content))
            
            # Resize for preview
            display_size = (400, 400)
            image.thumbnail(display_size, Image.Resampling.LANCZOS)
            
            photo = ImageTk.PhotoImage(image)
            self.preview_label.config(image=photo)
            self.preview_label.image = photo
            
            # Update info
            self.info_label.config(
                text=f"File: {file_data['name']}\n"
                     f"Size: {file_data['size']:,} bytes\n"
                     f"SHA: {file_data['sha'][:8]}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error loading preview: {str(e)}")
    
    def setup_repository(self):
        """Setup local repository"""
        try:
            # Create directory in user's AppData/Local folder
            app_data = os.path.join(os.environ['LOCALAPPDATA'], 'LabelManager')
            repo_dir = os.path.join(app_data, 'Repository')
            
            # Create app directory if it doesn't exist
            if not os.path.exists(app_data):
                os.makedirs(app_data)
            
            # Remove existing repo if it exists
            if os.path.exists(repo_dir):
                try:
                    shutil.rmtree(repo_dir)
                except PermissionError:
                    # If can't remove, try to work with existing repo
                    self.local_repo_path = repo_dir
                    return True
            
            try:
                os.makedirs(repo_dir)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to create repository directory: {str(e)}")
                return False
            
            self.local_repo_path = repo_dir
            
            # Clone repository
            self.set_status("Cloning repository...")
            result = subprocess.run(
                ["git", "clone", self.repo_url, self.local_repo_path],
                capture_output=True,
                text=True
            )
            
            if result.returncode != 0:
                raise Exception(f"Failed to clone repository: {result.stderr}")
            
            # Configure Git
            subprocess.run(["git", "config", "user.name", "Label Manager"], cwd=self.local_repo_path)
            subprocess.run(["git", "config", "user.email", "label.manager@example.com"], 
                         cwd=self.local_repo_path)
            
            return True
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to setup repository: {str(e)}")
            return False

    def git_command(self, command, error_message="Git operation failed"):
        """Run a git command in the repository directory"""
        try:
            result = subprocess.run(
                command,
                cwd=self.local_repo_path,
                capture_output=True,
                text=True
            )
            
            if result.returncode != 0:
                raise Exception(f"{error_message}: {result.stderr}")
            
            return result.stdout.strip()
            
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return None

    def upload_files(self):
        """Handle file upload using Git"""
        files = filedialog.askopenfilenames(
            title="Select Label Files to Upload",
            filetypes=[
                ("Label files", "*.png *.jpg *.jpeg"),
                ("All files", "*.*")
            ]
        )
        
        if not files:
            return
        
        # Check file sizes
        large_files = []
        for file in files:
            size_mb = os.path.getsize(file) / (1024 * 1024)
            if size_mb > 25:
                large_files.append(f"{os.path.basename(file)} ({size_mb:.1f} MB)")
        
        if large_files:
            messagebox.showerror(
                "Files Too Large",
                "These files exceed GitHub's 25 MB limit:\n\n" +
                "\n".join(large_files)
            )
            return
        
        try:
            # Pull latest changes
            self.set_status("Pulling latest changes...")
            self.git_command(["git", "pull"], "Failed to pull latest changes")
            
            # Copy files to repository
            target_dir = os.path.join(self.local_repo_path, self.labels_path)
            os.makedirs(target_dir, exist_ok=True)
            
            self.set_status("Copying files...")
            for file in files:
                shutil.copy2(file, target_dir)
            
            # Add files to Git
            self.set_status("Adding files to Git...")
            file_list = [os.path.basename(f) for f in files]
            commit_files = [os.path.join(self.labels_path, f) for f in file_list]
            
            self.git_command(["git", "add"] + commit_files,
                           "Failed to add files to Git")
            
            # Create commit
            commit_msg = f"Added {len(files)} new label file(s)\n\n" + \
                        "\n".join(f"- {f}" for f in file_list)
            
            self.git_command(["git", "commit", "-m", commit_msg],
                           "Failed to create commit")
            
            # Push changes
            self.set_status("Pushing changes to GitHub...")
            self.git_command(["git", "push"], "Failed to push changes")
            
            messagebox.showinfo(
                "Success",
                f"Successfully uploaded {len(files)} file(s) to GitHub"
            )
            
            self.refresh_files()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to upload files: {str(e)}")

    def delete_files(self):
        """Handle file deletion using Git"""
        selected_indices = self.file_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("Warning", "Please select files to delete")
            return
        
        selected_files = [self.file_listbox.get(i) for i in selected_indices]
        
        if not messagebox.askyesno(
            "Confirm Delete",
            f"Are you sure you want to delete these {len(selected_files)} file(s)?\n\n" +
            "\n".join(f"- {f}" for f in selected_files) + "\n\n" +
            "This action cannot be undone!",
            icon='warning'
        ):
            return
        
        try:
            # Pull latest changes
            self.set_status("Pulling latest changes...")
            self.git_command(["git", "pull"], "Failed to pull latest changes")
            
            # Remove files
            self.set_status("Removing files...")
            file_paths = [os.path.join(self.labels_path, f) for f in selected_files]
            
            self.git_command(["git", "rm"] + file_paths,
                           "Failed to remove files from Git")
            
            # Create commit
            commit_msg = f"Deleted {len(selected_files)} label file(s)\n\n" + \
                        "\n".join(f"- {f}" for f in selected_files)
            
            self.git_command(["git", "commit", "-m", commit_msg],
                           "Failed to create commit")
            
            # Push changes
            self.set_status("Pushing changes to GitHub...")
            self.git_command(["git", "push"], "Failed to push changes")
            
            messagebox.showinfo(
                "Success",
                f"Successfully deleted {len(selected_files)} file(s) from GitHub"
            )
            
            self.refresh_files()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete files: {str(e)}")

    def download_labels(self):
        """Download selected labels to a user-specified directory"""
        try:
            # Get selected items
            selected_indices = self.file_listbox.curselection()
            if not selected_indices:
                messagebox.showinfo("Info", "Please select labels to download")
                return

            # Ask user for download directory
            download_dir = filedialog.askdirectory(title="Select Download Directory")
            if not download_dir:
                return

            # Download selected files directly from GitHub
            copied_files = 0
            errors = []
            
            for index in selected_indices:
                filename = self.file_listbox.get(index)
                file_data = next((f for f in self.files_data if f['name'] == filename), None)
                
                if not file_data:
                    errors.append(f"Could not find data for {filename}")
                    continue
                
                try:
                    # Download file from GitHub
                    response = requests.get(file_data['download_url'])
                    if response.status_code != 200:
                        errors.append(f"Failed to download {filename}: HTTP {response.status_code}")
                        continue
                    
                    # Save file
                    dst = os.path.join(download_dir, filename)
                    with open(dst, 'wb') as f:
                        f.write(response.content)
                    copied_files += 1
                    
                except Exception as e:
                    errors.append(f"Failed to save {filename}: {str(e)}")

            # Show results
            if copied_files > 0:
                success_msg = f"Downloaded {copied_files} label file(s) to {download_dir}"
                if errors:
                    success_msg += "\n\nSome files had errors:\n" + "\n".join(errors)
                messagebox.showinfo("Download Complete", success_msg)
            else:
                error_msg = "No files were downloaded due to errors:\n\n" + "\n".join(errors)
                messagebox.showerror("Error", error_msg)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to download labels: {str(e)}")

    def show_duplicates(self):
        """Find and display files that share the same 12-digit SKU"""
        # Dictionary to store files by SKU
        sku_files = {}
        
        # Regular expression to find 12 consecutive digits
        sku_pattern = re.compile(r'\d{12}')
        
        # Group files by SKU
        for file in self.files_data:
            if file['type'] == 'file':
                filename = file['name']
                match = sku_pattern.search(filename)
                if match:
                    sku = match.group()
                    if sku not in sku_files:
                        sku_files[sku] = []
                    sku_files[sku].append(filename)
        
        # Filter for SKUs with multiple files
        duplicates = {sku: files for sku, files in sku_files.items() if len(files) > 1}
        
        if not duplicates:
            messagebox.showinfo("No Duplicates", "No files sharing the same SKU were found.")
            return
        
        # Create a new window to display duplicates
        dup_window = tk.Toplevel(self.root)
        dup_window.title("Duplicate SKUs")
        dup_window.geometry("1000x600")
        dup_window.configure(bg='#ecf0f1')
        
        # Create main container with padding
        main_container = tk.Frame(dup_window, bg='#ecf0f1')
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create left panel for the list
        left_panel = tk.Frame(main_container, bg='#ecf0f1')
        left_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Add a header with explanation
        header = tk.Label(left_panel, 
                         text="Files sharing the same SKU number:\n" +
                              "Select files to preview and delete duplicates",
                         bg='#ecf0f1', fg='#2c3e50', 
                         font=('TkDefaultFont', 10, 'bold'),
                         justify=tk.LEFT)
        header.pack(fill=tk.X, pady=(0, 10))
        
        # Create a treeview to display the duplicates
        tree = ttk.Treeview(left_panel, columns=('SKU', 'Filename'), show='headings')
        tree.heading('SKU', text='SKU')
        tree.heading('Filename', text='Filename')
        tree.column('SKU', width=120)
        tree.column('Filename', width=300)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(left_panel, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack the treeview and scrollbar
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Create right panel for preview
        right_panel = tk.Frame(main_container, bg='#ecf0f1', width=400)
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(10, 0))
        right_panel.pack_propagate(False)
        
        # Preview header
        preview_label = tk.Label(right_panel, 
                               text="Label Preview\n" +
                                    "(Select a file on the left to preview)",
                               bg='#ecf0f1', fg='#2c3e50', 
                               font=('TkDefaultFont', 10, 'bold'))
        preview_label.pack(fill=tk.X, pady=(0, 10))
        
        # Image preview
        preview_frame = tk.Frame(right_panel, bg='#ecf0f1')
        preview_frame.pack(fill=tk.BOTH, expand=True)
        
        image_label = tk.Label(preview_frame, bg='#ecf0f1')
        image_label.pack(fill=tk.BOTH, expand=True)
        
        # File info label
        info_label = tk.Label(right_panel, text="", wraplength=380,
                            bg='#ecf0f1', fg='#2c3e50', justify=tk.LEFT)
        info_label.pack(fill=tk.X, pady=(10, 0))
        
        # Delete button - made larger and more prominent
        delete_btn = tk.Button(right_panel, 
                             text="❌ Delete Selected Labels",
                             command=lambda: self.delete_selected_duplicates(tree, dup_window),
                             bg='#e74c3c',
                             activebackground='#c0392b',
                             fg='white',
                             height=2,
                             width=20,
                             font=('TkDefaultFont', 10, 'bold'))
        delete_btn.pack(pady=10)
        
        def on_select(event):
            """Handle selection in the treeview"""
            selected_items = tree.selection()
            if not selected_items:
                image_label.config(image='')
                info_label.config(text='')
                return
            
            # Get the last selected item
            item = selected_items[-1]
            filename = tree.item(item)['values'][1]
            
            try:
                # Find file data
                file_data = next((f for f in self.files_data if f['name'] == filename), None)
                if not file_data:
                    return
                
                # Load and display image
                response = requests.get(file_data['download_url'])
                if response.status_code != 200:
                    raise Exception(f"Failed to fetch image: HTTP {response.status_code}")
                
                image = Image.open(BytesIO(response.content))
                
                # Resize for preview while maintaining aspect ratio
                display_size = (380, 380)
                image.thumbnail(display_size, Image.Resampling.LANCZOS)
                
                photo = ImageTk.PhotoImage(image)
                image_label.config(image=photo)
                image_label.image = photo  # Keep a reference
                
                # Update info
                info_label.config(
                    text=f"Filename: {file_data['name']}\n"
                         f"Size: {file_data['size']:,} bytes\n"
                         f"Last modified: {file_data.get('last_modified', 'Unknown')}"
                )
                
            except Exception as e:
                messagebox.showerror("Error", f"Error loading preview: {str(e)}")
        
        # Bind selection event
        tree.bind('<<TreeviewSelect>>', on_select)

        # Populate the treeview
        for sku, files in duplicates.items():
            for filename in files:
                tree.insert('', tk.END, values=(sku, filename))

    def delete_selected_duplicates(self, tree, window):
        """Delete selected files from the duplicates view"""
        selected_items = tree.selection()
        if not selected_items:
            messagebox.showwarning("Warning", "Please select files to delete")
            return
        
        selected_files = [tree.item(item)['values'][1] for item in selected_items]
        
        if not messagebox.askyesno(
            "Confirm Delete",
            f"Are you sure you want to delete these {len(selected_files)} file(s)?\n\n" +
            "\n".join(f"- {f}" for f in selected_files) + "\n\n" +
            "This action cannot be undone!",
            icon='warning'
        ):
            return
        
        try:
            # Pull latest changes
            self.set_status("Pulling latest changes...")
            self.git_command(["git", "pull"], "Failed to pull latest changes")
            
            # Remove files
            self.set_status("Removing files...")
            file_paths = [os.path.join(self.labels_path, f) for f in selected_files]
            
            self.git_command(["git", "rm"] + file_paths,
                           "Failed to remove files from Git")
            
            # Create commit
            commit_msg = f"Deleted {len(selected_files)} duplicate label file(s)\n\n" + \
                        "\n".join(f"- {f}" for f in selected_files)
            
            self.git_command(["git", "commit", "-m", commit_msg],
                           "Failed to create commit")
            
            # Push changes
            self.set_status("Pushing changes to GitHub...")
            self.git_command(["git", "push"], "Failed to push changes")
            
            # Remove selected items from the treeview
            for item in selected_items:
                tree.delete(item)
            
            # Close the window if no more duplicates
            if len(tree.get_children()) == 0:
                window.destroy()
            
            # Refresh the main file list
            self.refresh_files()
            
            messagebox.showinfo(
                "Success",
                f"Successfully deleted {len(selected_files)} file(s)"
            )
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete files: {str(e)}")

    def __del__(self):
        """Cleanup temporary repository"""
        if self.local_repo_path and os.path.exists(self.local_repo_path):
            try:
                shutil.rmtree(self.local_repo_path)
            except:
                pass

def main():
    root = tk.Tk()
    root.title("Label Manager - Omar27522/Projects")
    
    # Set style
    style = ttk.Style()
    style.theme_use('clam')  # or 'vista' on Windows
    
    app = GitHubLabelManager(root)
    root.mainloop()

if __name__ == "__main__":
    main()

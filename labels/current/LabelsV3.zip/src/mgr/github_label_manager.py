import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import requests
import os
from PIL import Image, ImageTk
from io import BytesIO
import webbrowser
import json
import threading
import pytesseract
from datetime import datetime
import subprocess
import shutil
import tempfile
import re
import hashlib

class GitHubLabelManager:
    def __init__(self, root):
        self.root = root
        self.root.title("Label Manager - Omar27522/Projects")
        self.root.geometry("1000x700")
        
        # Configure Tesseract path - use the installed version
        tesseract_path = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
        if os.path.exists(tesseract_path):
            pytesseract.pytesseract.tesseract_cmd = tesseract_path
        
        # Repository details
        self.repo_owner = "Omar27522"
        self.repo_name = "Projects"
        self.labels_path = "labels/files"
        self.repo_url = f"https://github.com/{self.repo_owner}/{self.repo_name}"
        
        # Setup headers for GitHub API - using unauthenticated access for public repos
        self.headers = {
            'Accept': 'application/vnd.github.v3+json'
        }
        
        # Configure root background
        self.root.configure(bg='#ecf0f1')
        
        # Local repository path
        self.local_repo_path = None
        
        # Initialize status bar with colors
        self.status_var = tk.StringVar()
        self.status_bar = tk.Label(root, textvariable=self.status_var, bd=1, 
                                 relief=tk.SUNKEN, anchor=tk.W,
                                 bg='#3498db', fg='white')  # Blue background with white text
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Initialize repository
        if not self.setup_repository():
            messagebox.showerror("Error", "Failed to initialize repository. Please ensure Git is installed.")
            root.destroy()
            return
        
        # Set window icon (GitHub icon)
        try:
            icon_url = "https://github.com/favicon.ico"
            icon_response = requests.get(icon_url)
            if icon_response.status_code == 200:
                icon_data = BytesIO(icon_response.content)
                icon_image = Image.open(icon_data)
                icon_photo = ImageTk.PhotoImage(icon_image)
                self.root.iconphoto(True, icon_photo)
        except:
            pass  # Ignore icon loading errors
        
        # Configure style
        style = ttk.Style()
        style.configure('Header.TLabel', 
                       font=('TkDefaultFont', 11),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        style.configure('FileCount.TLabel', 
                       font=('TkDefaultFont', 9),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        style.configure('Action.TButton', 
                       padding=5,
                       background='#3498db',
                       foreground='white')
        style.configure('Counter.TLabel', 
                       font=('TkDefaultFont', 11),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        style.configure('Preview.TLabelframe', 
                       font=('TkDefaultFont', 10, 'bold'),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        style.configure('FileList.TLabelframe', 
                       font=('TkDefaultFont', 10, 'bold'),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        style.configure('Search.TLabel', 
                       font=('TkDefaultFont', 10, 'bold'),
                       background='#ecf0f1',
                       foreground='#2c3e50')
        
        # Create main container with padding and background
        self.main_container = tk.Frame(root, bg='#ecf0f1', padx=10, pady=10)
        self.main_container.pack(fill=tk.BOTH, expand=True)
        
        # Create progress bar (hidden by default)
        self.progress_frame = tk.Frame(self.main_container, bg='#ecf0f1')
        self.progress_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(self.progress_frame, 
                                          variable=self.progress_var,
                                          mode='determinate',
                                          length=300)
        
        self.progress_label = ttk.Label(self.progress_frame, 
                                      text="",
                                      style='Header.TLabel')
        
        # Create header frame
        self.create_header_frame()
        
        # Create file list frame
        self.create_file_list()
        
        # Create preview frame
        self.create_preview_frame()
        
        # Initialize variables
        self.current_image = None
        self.files_data = []
        self.last_refresh = None
        
        # Load initial data
        self.set_status("Loading repository files...")
        self.refresh_files()

    def create_header_frame(self):
        """Create the header frame with repository info and controls"""
        header_frame = tk.Frame(self.main_container, bg='#ecf0f1')
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Repository info
        info_frame = tk.Frame(header_frame, bg='#ecf0f1')
        info_frame.pack(side=tk.LEFT)
        
        repo_label = ttk.Label(info_frame, text="GitHub Repository:",
                             style='Header.TLabel')
        repo_label.pack(side=tk.LEFT)
        
        repo_link = tk.Label(info_frame, text=self.repo_url,
                         fg='#3498db', cursor='hand2',
                         bg='#ecf0f1')
        repo_link.pack(side=tk.LEFT, padx=5)
        repo_link.bind('<Button-1>', 
                      lambda e: webbrowser.open(self.repo_url))
        
        # Last refresh time
        self.refresh_label = tk.Label(info_frame, text="",
                                  bg='#ecf0f1', fg='#2c3e50')
        self.refresh_label.pack(side=tk.LEFT, padx=20)

    def create_file_list(self):
        """Create the file list frame"""
        list_frame = ttk.LabelFrame(self.main_container, text="Label Files",
                                  style='FileList.TLabelframe')
        list_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Create search frame
        search_frame = tk.Frame(list_frame, bg='#ecf0f1')
        search_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Search entry
        search_label = ttk.Label(search_frame, text="Search:",
                               style='Search.TLabel')
        search_label.pack(side=tk.LEFT)
        
        self.search_var = tk.StringVar()
        self.search_var.trace('w', self.filter_files)
        
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var,
                               font=('TkDefaultFont', 11))
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        # File counter
        self.file_count_label = ttk.Label(search_frame, text="0 files",
                                        style='Counter.TLabel')
        self.file_count_label.pack(side=tk.LEFT, padx=(5, 0))
        
        # Control buttons frame
        controls_frame = tk.Frame(list_frame, bg='#ecf0f1')
        controls_frame.pack(fill=tk.X, pady=5, padx=5)
        
        # Big buttons with icons
        button_height = 2
        button_width = 15
        
        refresh_btn = tk.Button(controls_frame, text="🔄 Refresh Files",
                            command=self.refresh_files,
                            bg='#3498db',
                            activebackground='#2980b9',
                            fg='white',
                            height=button_height,
                            width=button_width,
                            font=('TkDefaultFont', 10))
        refresh_btn.pack(side=tk.LEFT, padx=2)
        
        show_duplicates_btn = tk.Button(controls_frame, text="🔍 Find Duplicates",
                                    command=self.show_duplicates,
                                    bg='#e67e22',
                                    activebackground='#d35400',
                                    fg='white',
                                    height=button_height,
                                    width=button_width,
                                    font=('TkDefaultFont', 10))
        show_duplicates_btn.pack(side=tk.LEFT, padx=2)
        
        upload_btn = tk.Button(controls_frame, text="⬆️ Upload Labels",
                           command=self.upload_files,
                           bg='#2ecc71',
                           activebackground='#27ae60',
                           fg='white',
                           height=button_height,
                           width=button_width,
                           font=('TkDefaultFont', 10))
        upload_btn.pack(side=tk.LEFT, padx=2)
        
        rename_btn = tk.Button(controls_frame, text="✏️ Rename File",
                           command=self.rename_file,
                           bg='#9b59b6',
                           activebackground='#8e44ad',
                           fg='white',
                           height=button_height,
                           width=button_width,
                           font=('TkDefaultFont', 10))
        rename_btn.pack(side=tk.LEFT, padx=2)
        
        delete_btn = tk.Button(controls_frame, text="❌ Delete Selected",
                           command=self.delete_files,
                           bg='#e74c3c',
                           activebackground='#c0392b',
                           fg='white',
                           height=button_height,
                           width=button_width,
                           font=('TkDefaultFont', 10))
        delete_btn.pack(side=tk.LEFT, padx=2)
        
        # Create listbox with scrollbar
        listbox_frame = tk.Frame(list_frame)
        listbox_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.file_listbox = tk.Listbox(listbox_frame,
                                     selectmode=tk.EXTENDED,
                                     font=('TkDefaultFont', 11),
                                     bg='white',
                                     fg='#2c3e50',
                                     selectbackground='#3498db',
                                     selectforeground='white')
        self.file_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(listbox_frame, orient=tk.VERTICAL,
                                command=self.file_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.file_listbox.config(yscrollcommand=scrollbar.set)
        
        # Bind selection event
        self.file_listbox.bind('<<ListboxSelect>>', self.on_select)

    def create_preview_frame(self):
        """Create the preview frame"""
        preview_frame = ttk.LabelFrame(self.main_container, text="Preview",
                                     style='Preview.TLabelframe')
        preview_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10, 0))
        
        # Create canvas for image preview
        self.preview_canvas = tk.Canvas(preview_frame, bg='white',
                                      width=400, height=400)
        self.preview_canvas.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # File info frame
        info_frame = tk.Frame(preview_frame, bg='#ecf0f1')
        info_frame.pack(fill=tk.X, pady=5)
        
        self.info_label = tk.Label(info_frame, text="", wraplength=400,
                               bg='#ecf0f1', fg='#2c3e50')
        self.info_label.pack(fill=tk.X)
        
        # Action buttons
        buttons_frame = tk.Frame(preview_frame, bg='#ecf0f1')
        buttons_frame.pack(fill=tk.X)
        
        # Download button with purple theme
        download_btn = tk.Button(buttons_frame, text="Download Labels",
                             command=self.download_labels,
                             bg='#9b59b6',  # Bright purple
                             activebackground='#8e44ad',  # Darker purple when clicked
                             fg='white',
                             relief='raised')
        download_btn.pack(side=tk.LEFT, padx=5)
        
        # Store the current preview image reference
        self.current_preview_image = None

    def set_status(self, message):
        """Update status bar message"""
        self.status_var.set(message)
        self.root.update_idletasks()

    def refresh_files(self):
        """Refresh the list of files"""
        try:
            self.show_progress(True, "Refreshing files...")
            
            # Get all files from the labels directory
            label_dir = os.path.join(self.local_repo_path, self.labels_path)
            if not os.path.exists(label_dir):
                self.show_progress(False)
                return
            
            # Clear current list
            self.file_listbox.delete(0, tk.END)
            
            # Get and sort all image files
            image_files = []
            for file in os.listdir(label_dir):
                if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                    image_files.append(file)
            
            image_files.sort(key=str.lower)
            total_files = len(image_files)
            
            # Add files to listbox with progress updates
            for i, file in enumerate(image_files):
                self.file_listbox.insert(tk.END, file)
                progress = ((i + 1) / total_files) * 100
                self.update_progress(progress, f"Loading files... ({i + 1}/{total_files})")
            
            # Update file counter
            self.update_file_counter(total_files)
            
            # Update status
            self.set_status(f"Found {total_files} files")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error refreshing files: {str(e)}")
        finally:
            self.show_progress(False)

    def update_file_counter(self, count):
        """Update the file counter in the search frame"""
        if hasattr(self, 'file_count_label'):
            self.file_count_label.config(text=f"{count} files")

    def git_command(self, command, error_message="Git command failed"):
        """Execute a git command"""
        try:
            print(f"\nExecuting Git Command: {' '.join(command)}")
            result = subprocess.run(
                command,
                cwd=self.local_repo_path,
                capture_output=True,
                text=True,
                check=True
            )
            print(f"Git Command Output: {result.stdout}")
            return result.stdout.strip()
            
        except subprocess.CalledProcessError as e:
            print(f"\nGit Command Error:")
            print(f"Command: {' '.join(command)}")
            print(f"Exit Code: {e.returncode}")
            print(f"Stdout: {e.stdout}")
            print(f"Stderr: {e.stderr}")
            raise Exception(f"{error_message}: {e.stderr}")

    def update_file_list(self):
        """Update the listbox with files"""
        self.file_listbox.delete(0, tk.END)
        search_term = self.search_var.get().lower()
        
        displayed_files = []
        for file in self.files_data:
            if file['type'] == 'file' and file['name'].lower().endswith(('.png', '.jpg', '.jpeg')):
                if search_term in file['name'].lower():
                    displayed_files.append(file)
                    self.file_listbox.insert(tk.END, file['name'])
        
        self.update_file_counter(len(displayed_files))
    
    def filter_files(self, *args):
        """Filter files based on search term"""
        search_term = self.search_var.get().lower()
        self.file_listbox.delete(0, tk.END)
        
        # Get all files from the labels directory
        label_dir = os.path.join(self.local_repo_path, self.labels_path)
        if not os.path.exists(label_dir):
            return
        
        # Filter and display matching files
        matching_files = []
        for file in os.listdir(label_dir):
            if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                if search_term in file.lower():
                    matching_files.append(file)
        
        # Sort files
        matching_files.sort(key=str.lower)
        
        # Add matching files to listbox
        for file in matching_files:
            self.file_listbox.insert(tk.END, file)
        
        # Update file counter
        self.update_file_counter(len(matching_files))
        
        # Update status
        if search_term:
            self.set_status(f"Found {len(matching_files)} matching files")
        else:
            self.set_status("Ready")

    def on_select(self, event):
        """Handle file selection"""
        selection = self.file_listbox.curselection()
        if not selection:
            return
            
        try:
            # Get selected filename
            filename = self.file_listbox.get(selection[0])
            
            # Construct full path to the image
            image_path = os.path.join(self.local_repo_path, self.labels_path, filename)
            
            if not os.path.exists(image_path):
                print(f"Image file not found: {image_path}")
                return
            
            # Load and resize image for preview
            image = Image.open(image_path)
            
            # Calculate resize dimensions while maintaining aspect ratio
            canvas_width = self.preview_canvas.winfo_width()
            canvas_height = self.preview_canvas.winfo_height()
            
            # If canvas size is not yet set, use default dimensions
            if canvas_width <= 1:
                canvas_width = 400
            if canvas_height <= 1:
                canvas_height = 400
            
            # Calculate scaling factor
            width_ratio = canvas_width / image.width
            height_ratio = canvas_height / image.height
            scale_factor = min(width_ratio, height_ratio)
            
            # Calculate new dimensions
            new_width = int(image.width * scale_factor)
            new_height = int(image.height * scale_factor)
            
            # Resize image
            resized_image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
            
            # Convert to PhotoImage
            photo_image = ImageTk.PhotoImage(resized_image)
            
            # Clear previous image
            self.preview_canvas.delete("all")
            
            # Calculate center position
            x = (canvas_width - new_width) // 2
            y = (canvas_height - new_height) // 2
            
            # Display new image
            self.preview_canvas.create_image(x, y, anchor=tk.NW, image=photo_image)
            
            # Keep a reference to prevent garbage collection
            self.current_preview_image = photo_image
            
            # Update file info
            file_size = os.path.getsize(image_path)
            image_info = f"File: {filename}\n"
            image_info += f"Size: {file_size:,} bytes\n"
            image_info += f"Dimensions: {image.width} x {image.height} pixels"
            
            self.info_label.config(text=image_info)
            
            # Update status
            self.set_status(f"Showing preview: {filename}")
            
        except Exception as e:
            print(f"Error displaying image: {str(e)}")
            self.set_status(f"Error displaying image: {str(e)}")

    def show_progress(self, show=True, text="Processing..."):
        """Show or hide progress bar"""
        if show:
            self.progress_label.pack(side=tk.TOP, pady=(0, 5))
            self.progress_bar.pack(side=tk.TOP)
            self.progress_label.config(text=text)
            self.progress_var.set(0)
            self.root.update_idletasks()
        else:
            self.progress_label.pack_forget()
            self.progress_bar.pack_forget()
            self.progress_var.set(0)
            self.root.update_idletasks()

    def update_progress(self, value, text=None):
        """Update progress bar value and optionally text"""
        self.progress_var.set(value)
        if text:
            self.progress_label.config(text=text)
        self.root.update_idletasks()

    def upload_files(self):
        """Handle file upload using Git"""
        files = filedialog.askopenfilenames(
            title="Select Label Files to Upload",
            filetypes=[
                ("Label files", "*.png *.jpg *.jpeg"),
                ("All files", "*.*")
            ]
        )
        
        if not files:
            return
        
        # Check file sizes
        large_files = []
        for file in files:
            size_mb = os.path.getsize(file) / (1024 * 1024)
            if size_mb > 25:
                large_files.append(f"{os.path.basename(file)} ({size_mb:.1f} MB)")
        
        if large_files:
            messagebox.showerror(
                "Files Too Large",
                "These files exceed GitHub's 25 MB limit:\n\n" +
                "\n".join(large_files)
            )
            return
        
        try:
            # Pull latest changes
            self.set_status("Pulling latest changes...")
            self.git_command(["git", "pull"], "Failed to pull latest changes")
            
            # Copy files to repository
            target_dir = os.path.join(self.local_repo_path, self.labels_path)
            os.makedirs(target_dir, exist_ok=True)
            
            self.show_progress(True, "Copying files...")
            for file in files:
                shutil.copy2(file, target_dir)
            
            # Add files to Git
            self.set_status("Adding files to Git...")
            file_list = [os.path.basename(f) for f in files]
            commit_files = [os.path.join(self.labels_path, f) for f in file_list]
            
            self.git_command(["git", "add"] + commit_files,
                           "Failed to add files to Git")
            
            # Create commit
            commit_msg = f"Added {len(files)} new label file(s)\n\n" + \
                        "\n".join(f"- {f}" for f in file_list)
            
            self.git_command(["git", "commit", "-m", commit_msg],
                           "Failed to create commit")
            
            # Push changes
            self.set_status("Pushing changes to GitHub...")
            self.git_command(["git", "push"], "Failed to push changes")
            
            messagebox.showinfo(
                "Success",
                f"Successfully uploaded {len(files)} file(s) to GitHub"
            )
            
            self.refresh_files()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to upload files: {str(e)}")

    def delete_files(self):
        """Handle file deletion using Git"""
        selected_indices = self.file_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("Warning", "Please select files to delete")
            return
        
        selected_files = [self.file_listbox.get(i) for i in selected_indices]
        
        if not messagebox.askyesno(
            "Confirm Delete",
            f"Are you sure you want to delete these {len(selected_files)} file(s)?\n\n" +
            "\n".join(f"- {f}" for f in selected_files) + "\n\n" +
            "This action cannot be undone!",
            icon='warning'
        ):
            return
        
        try:
            # Pull latest changes
            self.set_status("Pulling latest changes...")
            self.git_command(["git", "pull"], "Failed to pull latest changes")
            
            # Remove files
            self.set_status("Removing files...")
            file_paths = [os.path.join(self.labels_path, f) for f in selected_files]
            
            self.git_command(["git", "rm"] + file_paths,
                           "Failed to remove files from Git")
            
            # Create commit
            commit_msg = f"Deleted {len(selected_files)} label file(s)\n\n" + \
                        "\n".join(f"- {f}" for f in selected_files)
            
            self.git_command(["git", "commit", "-m", commit_msg],
                           "Failed to create commit")
            
            # Push changes
            self.set_status("Pushing changes to GitHub...")
            self.git_command(["git", "push"], "Failed to push changes")
            
            messagebox.showinfo(
                "Success",
                f"Successfully deleted {len(selected_files)} file(s) from GitHub"
            )
            
            self.refresh_files()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete files: {str(e)}")

    def download_labels(self):
        """Download selected labels to a user-specified directory"""
        try:
            # Get selected items
            selected_indices = self.file_listbox.curselection()
            if not selected_indices:
                messagebox.showinfo("Info", "Please select labels to download")
                return

            # Ask user for download directory
            download_dir = filedialog.askdirectory(title="Select Download Directory")
            if not download_dir:
                return

            # Copy selected files from local repository
            copied_files = 0
            errors = []
            
            label_dir = os.path.join(self.local_repo_path, self.labels_path)
            
            for index in selected_indices:
                filename = self.file_listbox.get(index)
                src_path = os.path.join(label_dir, filename)
                
                if not os.path.exists(src_path):
                    errors.append(f"Could not find file: {filename}")
                    continue
                
                try:
                    # Copy file to destination
                    dst_path = os.path.join(download_dir, filename)
                    shutil.copy2(src_path, dst_path)
                    copied_files += 1
                    
                except Exception as e:
                    errors.append(f"Failed to copy {filename}: {str(e)}")

            # Show results
            if copied_files > 0:
                success_msg = f"Downloaded {copied_files} label file(s) to {download_dir}"
                if errors:
                    success_msg += "\n\nSome files had errors:\n" + "\n".join(errors)
                messagebox.showinfo("Download Complete", success_msg)
            else:
                error_msg = "No files were downloaded due to errors:\n\n" + "\n".join(errors)
                messagebox.showerror("Error", error_msg)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to download labels: {str(e)}")

    def rename_file(self):
        """Rename selected files using OCR"""
        selection = self.file_listbox.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Please select files to rename")
            return
        
        try:
            self.show_progress(True, "Processing files for renaming...")
            total_files = len(selection)
            renamed_count = 0
            failed_files = []
            
            # Keep track of new filenames to handle duplicates
            new_names = {}  # Maps new_name to (old_path, creation_time)
            
            # First pass: Process all files and collect new names
            for i, index in enumerate(selection):
                filename = self.file_listbox.get(index)
                file_path = os.path.join(self.local_repo_path, self.labels_path, filename)
                
                self.update_progress(
                    ((i + 1) / total_files) * 50,  # First 50% for processing
                    f"Processing file {i + 1} of {total_files}: {filename}"
                )
                
                try:
                    # Extract text from image using OCR
                    image = Image.open(file_path)
                    
                    # Parse components
                    components = self.parse_label_text(image)
                    if not components:
                        failed_files.append(f"{filename} (couldn't extract components)")
                        continue
                    
                    product_name, variant, sku = components
                    new_name = f"{product_name}_{variant}_label_{sku}.png"
                    new_name = self.sanitize_filename(new_name)
                    creation_time = os.path.getctime(file_path)
                    
                    # If this new name already exists in our rename batch
                    if new_name in new_names:
                        old_time = new_names[new_name][1]
                        # Keep the newer file
                        if creation_time > old_time:
                            new_names[new_name] = (file_path, creation_time)
                    else:
                        new_names[new_name] = (file_path, creation_time)
                    
                except Exception as e:
                    failed_files.append(f"{filename} ({str(e)})")
                    continue
            
            # Second pass: Perform the actual renaming
            total_renames = len(new_names)
            current_rename = 0
            
            for new_name, (old_path, _) in new_names.items():
                current_rename += 1
                self.update_progress(
                    50 + (current_rename / total_renames) * 50,  # Last 50% for renaming
                    f"Renaming file {current_rename} of {total_renames}"
                )
                
                try:
                    new_path = os.path.join(self.local_repo_path, self.labels_path, new_name)
                    
                    # If the target file already exists but it's not in our batch
                    if os.path.exists(new_path) and new_path != old_path:
                        existing_time = os.path.getctime(new_path)
                        file_time = os.path.getctime(old_path)
                        
                        # If our file is newer, remove the existing file
                        if file_time > existing_time:
                            os.remove(new_path)
                        else:
                            # Existing file is newer, skip this one
                            os.remove(old_path)
                            continue
                    
                    # Perform the rename
                    os.rename(old_path, new_path)
                    renamed_count += 1
                    
                except Exception as e:
                    failed_files.append(f"{os.path.basename(old_path)} ({str(e)})")
                    continue
            
            # Refresh the file list
            self.refresh_files()
            
            # Show results
            message = f"Successfully renamed {renamed_count} files"
            if failed_files:
                message += f"\n\nFailed to rename {len(failed_files)} files:\n" + "\n".join(failed_files)
            
            if renamed_count > 0:
                messagebox.showinfo("Rename Complete", message)
            else:
                messagebox.showerror("Rename Failed", message)
            
        except Exception as e:
            messagebox.showerror("Error", f"Error renaming files: {str(e)}")
        finally:
            self.show_progress(False)

    def parse_label_text(self, image):
        """Extract product name, variant, and SKU from label text"""
        try:
            # Extract text from image using OCR
            text = pytesseract.image_to_string(image)
            
            # Debug: Print the extracted text
            print("\nExtracted Text from Image:")
            print("------------------------")
            print(text)
            print("------------------------")
            
            # Split text into lines and clean them
            lines = [line.strip() for line in text.split('\n') if line.strip()]
            print("\nCleaned Lines:")
            for line in lines:
                print(f"- {line}")
            
            # Find SKU (last line, should be 11-12 digits)
            sku = None
            if lines and re.match(r'^\d{11,12}$', lines[-1].strip()):
                sku = lines[-1].strip()
                # Ensure SKU is 12 digits, pad with 0 if needed
                sku = sku.zfill(12)
                print(f"\nFound SKU: {sku}")
                # Remove SKU line from further processing
                lines = lines[:-1]
            
            if not sku:
                print("\nERROR: No SKU found in text!")
                print("Looking for: 11-12 digit number in last line")
                print("Found lines:")
                for line in lines:
                    print(f"  - {line}")
                return None
            
            # Find variant (second to last line, before SKU)
            variant = None
            if lines:
                # Try standard variant format first (XXXVX)
                for line in lines:
                    if re.search(r'\b[A-Z]{3,4}V\d+\b', line):
                        variant = line.strip()
                        break
                
                # If no standard variant found, use the line before SKU
                if not variant and len(lines) >= 1:
                    variant = lines[-1].strip()
                    # Remove variant line from further processing
                    lines = lines[:-1]
            
            if not variant:
                print("\nERROR: No variant found in text!")
                print("Looking for: Line before the SKU")
                print("Found lines:")
                for line in lines:
                    print(f"  - {line}")
                return None
            
            # Remaining lines form the product name
            product_name_parts = []
            for line in lines:
                if line.lower() != 'label':  # Skip "Label" line
                    product_name_parts.append(line.strip())
            
            product_name = " ".join(product_name_parts)
            
            if not product_name:
                print("\nERROR: No product name found!")
                print("Looking for: Text lines before variant")
                print("Found lines:")
                for line in lines:
                    print(f"  - {line}")
                return None
            
            print(f"\nFound Product Name: {product_name}")
            
            # Clean up product name
            product_name = product_name.replace('_', ' ').strip()
            
            # Final validation
            if not all([product_name, variant, sku]):
                print("\nERROR: Missing required components!")
                print(f"Product Name: {'✓' if product_name else '✗'} ({product_name if product_name else 'Not found'})")
                print(f"Variant: {'✓' if variant else '✗'} ({variant if variant else 'Not found'})")
                print(f"SKU: {'✓' if sku else '✗'} ({sku if sku else 'Not found'})")
                return None
            
            print("\nSuccessfully extracted all components:")
            print(f"Product Name: {product_name}")
            print(f"Variant: {variant}")
            print(f"SKU: {sku}")
            
            return product_name.strip(), variant.strip(), sku.strip()
            
        except Exception as e:
            print(f"\nERROR: Exception while parsing text: {str(e)}")
            print("Full text being parsed:")
            print(text)
            return None
    
    def sanitize_filename(self, filename):
        """Clean filename to be valid"""
        # Replace invalid characters
        invalid_chars = '<>:"/\\|?*'
        for char in invalid_chars:
            filename = filename.replace(char, '_')
        
        # Remove leading/trailing spaces and dots
        filename = filename.strip('. ')
        
        # Ensure filename is not too long (Windows limit is 255)
        if len(filename) > 255:
            name, ext = os.path.splitext(filename)
            filename = name[:255-len(ext)] + ext
            
        return filename

    def get_file_hash(self, filepath):
        """Calculate SHA-256 hash of a file"""
        sha256_hash = hashlib.sha256()
        with open(filepath, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    def extract_numbers(self, filename):
        """Extract all numbers from filename"""
        return ''.join(re.findall(r'\d+', filename))

    def extract_12digit_numbers(self, filename):
        """Extract all 12-digit numbers from filename"""
        return re.findall(r'\d{12}', filename)

    def show_duplicates(self):
        """Show duplicate files based on 12-digit numbers in filenames"""
        try:
            self.show_progress(True, "Finding duplicates...")
            
            label_dir = os.path.join(self.local_repo_path, self.labels_path)
            if not os.path.exists(label_dir):
                return
            
            # Dictionary to store files by their 12-digit numbers
            number_map = {}
            
            # Get all image files
            image_files = [f for f in os.listdir(label_dir) 
                         if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
            total_files = len(image_files)
            
            # Find duplicates based on 12-digit numbers in filenames
            for i, filename in enumerate(image_files):
                self.update_progress(
                    (i + 1) / total_files * 100,
                    f"Scanning files... ({i + 1}/{total_files})"
                )
                
                # Find all 12-digit numbers in the filename
                numbers = self.extract_12digit_numbers(filename)
                for number in numbers:
                    if number not in number_map:
                        number_map[number] = []
                    number_map[number].append(filename)
            
            # Filter for numbers with multiple files
            duplicates = {num: files for num, files in number_map.items() 
                        if len(files) > 1}
            
            if not duplicates:
                messagebox.showinfo("No Duplicates", 
                                  "No files sharing 12-digit numbers were found.")
                self.show_progress(False)
                return
            
            # Create duplicate files dialog
            dialog = tk.Toplevel(self.root)
            dialog.title("Files with 12-Digit Numbers")
            dialog.geometry("1200x800")
            
            # Create main container with padding
            main_container = ttk.Frame(dialog, padding="10")
            main_container.pack(fill=tk.BOTH, expand=True)
            
            # Add header with count
            header_frame = ttk.Frame(main_container)
            header_frame.pack(fill=tk.X, pady=(0, 10))
            
            count_text = f"Found {sum(len(files) for files in duplicates.values())} files in {len(duplicates)} groups"
            header_label = ttk.Label(
                header_frame,
                text=count_text,
                font=('TkDefaultFont', 10, 'bold')
            )
            header_label.pack(side=tk.LEFT)
            
            # Create left panel for tree
            left_panel = ttk.Frame(main_container)
            left_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            
            # Add search frame
            search_frame = ttk.Frame(left_panel)
            search_frame.pack(fill=tk.X, pady=(0, 5))
            
            search_label = ttk.Label(search_frame, text="Search:")
            search_label.pack(side=tk.LEFT, padx=(0, 5))
            
            search_var = tk.StringVar()
            search_entry = ttk.Entry(search_frame, textvariable=search_var)
            search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
            
            def filter_tree(*args):
                """Filter tree based on search text"""
                search_text = search_var.get().lower()
                for group in tree.get_children():
                    # Get all children of the group
                    children = tree.get_children(group)
                    show_group = False
                    
                    # Check each child
                    for child in children:
                        item = tree.item(child)
                        # Check if search text is in filename or number
                        if (search_text in item['values'][0].lower() or
                            search_text in str(item['values'][1]).lower()):
                            tree.item(child, tags=('file',))
                            show_group = True
                        else:
                            tree.item(child, tags=('hidden',))
                    
                    # Show/hide group based on children
                    if show_group:
                        tree.item(group, tags=('group',))
                        tree.item(group, open=True)  # Expand matching groups
                    else:
                        tree.item(group, tags=('hidden',))
            
            search_var.trace('w', filter_tree)
            
            # Create tree frame with border
            tree_frame = ttk.LabelFrame(left_panel, text="File Groups", padding="5")
            tree_frame.pack(fill=tk.BOTH, expand=True)
            
            # Create treeview with custom style
            style = ttk.Style()
            style.configure("Custom.Treeview", rowheight=25)
            style.configure("Custom.Treeview.Heading", font=('TkDefaultFont', 9, 'bold'))
            
            tree = ttk.Treeview(
                tree_frame,
                columns=('Filename', 'Number', 'Created', 'Size'),
                show='headings',
                style="Custom.Treeview"
            )
            
            tree.heading('Filename', text='Filename')
            tree.heading('Number', text='12-Digit Number')
            tree.heading('Created', text='Created')
            tree.heading('Size', text='Size')
            
            tree.column('Filename', width=300, anchor='w')
            tree.column('Number', width=100, anchor='center')
            tree.column('Created', width=150, anchor='center')
            tree.column('Size', width=100, anchor='e')
            
            # Add scrollbar
            tree_scroll = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, 
                                      command=tree.yview)
            tree.configure(yscrollcommand=tree_scroll.set)
            
            # Pack tree and scrollbar
            tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)
            
            # Create right panel for preview
            right_panel = ttk.Frame(main_container)
            right_panel.pack(side=tk.LEFT, fill=tk.BOTH, padx=(10, 0))
            
            # Create preview frame
            preview_frame = ttk.LabelFrame(right_panel, text="Preview", padding="5")
            preview_frame.pack(fill=tk.BOTH, expand=True)
            
            # Add preview info
            info_frame = ttk.Frame(preview_frame)
            info_frame.pack(fill=tk.X, pady=(0, 5))
            
            info_label = ttk.Label(info_frame, text="", wraplength=300)
            info_label.pack(fill=tk.X)
            
            # Add preview canvas with border
            preview_canvas = tk.Canvas(
                preview_frame,
                width=400,
                height=400,
                bg='white',
                relief='solid',
                borderwidth=1
            )
            preview_canvas.pack(fill=tk.BOTH, expand=True)
            
            # Create button frame at bottom
            button_frame = ttk.Frame(main_container)
            button_frame.pack(fill=tk.X, pady=(10, 0))
            
            def select_all_in_group():
                """Select all files in the current group"""
                selection = tree.selection()
                if not selection:
                    return
                    
                # Get the group of the selected item
                item = selection[0]
                parent = tree.parent(item)
                if not parent:  # If item is a group
                    group = item
                else:  # If item is a file
                    group = parent
                    
                # Select all visible files in the group
                for child in tree.get_children(group):
                    if 'hidden' not in tree.item(child, 'tags'):
                        tree.selection_add(child)
            
            def on_select(event):
                """Handle tree selection"""
                selection = tree.selection()
                if not selection:
                    info_label.config(text="")
                    preview_canvas.delete('all')
                    return
                
                item = tree.item(selection[0])
                if 'file' not in tree.item(selection[0], 'tags'):
                    info_label.config(text="")
                    preview_canvas.delete('all')
                    return
                
                filename = item['values'][0]
                if not filename:
                    return
                
                # Update info label
                number = item['values'][1]
                created = item['values'][2]
                size = item['values'][3]
                info_text = f"Filename: {filename}\n"
                info_text += f"12-Digit Number: {number}\n"
                info_text += f"Created: {created}\n"
                info_text += f"Size: {size}"
                info_label.config(text=info_text)
                
                # Load and display preview
                try:
                    filepath = os.path.join(label_dir, filename)
                    image = Image.open(filepath)
                    
                    # Calculate scaling
                    canvas_width = preview_canvas.winfo_width()
                    canvas_height = preview_canvas.winfo_height()
                    
                    # Scale image
                    scale = min(canvas_width/image.width, 
                              canvas_height/image.height)
                    new_width = int(image.width * scale)
                    new_height = int(image.height * scale)
                    
                    image = image.resize((new_width, new_height), 
                                      Image.Resampling.LANCZOS)
                    photo = ImageTk.PhotoImage(image)
                    
                    # Clear canvas and show image
                    preview_canvas.delete('all')
                    x = (canvas_width - new_width) // 2
                    y = (canvas_height - new_height) // 2
                    preview_canvas.create_image(x, y, anchor=tk.NW, image=photo)
                    preview_canvas.image = photo
                    
                except Exception as e:
                    print(f"Error loading preview: {str(e)}")
            
            # Bind selection event
            tree.bind('<<TreeviewSelect>>', on_select)
            
            # Add buttons
            ttk.Button(
                button_frame,
                text="Select All in Group",
                command=select_all_in_group
            ).pack(side=tk.LEFT, padx=5)
            
            ttk.Button(
                button_frame,
                text="Delete Selected",
                command=lambda: delete_selected(tree, label_dir),
                style="Accent.TButton"
            ).pack(side=tk.LEFT, padx=5)
            
            ttk.Button(
                button_frame,
                text="Close",
                command=dialog.destroy
            ).pack(side=tk.RIGHT, padx=5)
            
            # Configure styles
            style.configure("Accent.TButton", 
                          foreground="red",
                          font=('TkDefaultFont', 9, 'bold'))
            
            # Configure tag appearance
            tree.tag_configure('group', background='#e0e0e0', 
                             font=('TkDefaultFont', 9, 'bold'))
            tree.tag_configure('file', background='white')
            tree.tag_configure('hidden', background='white')
            
            # Populate treeview with duplicate groups
            for number, files in duplicates.items():
                # Add group header
                group = tree.insert('', tk.END, text=f"Group - {number}",
                                  values=('', '', '', ''),
                                  tags=('group',))
                
                # Add files in group
                for filename in files:
                    filepath = os.path.join(label_dir, filename)
                    created = datetime.fromtimestamp(
                        os.path.getctime(filepath)
                    ).strftime('%Y-%m-%d %H:%M:%S')
                    size = f"{os.path.getsize(filepath):,} bytes"
                    
                    tree.insert(group, tk.END, 
                              values=(filename, number, created, size),
                              tags=('file',))
                              
                # Expand group by default
                tree.item(group, open=True)
            
            def delete_selected(tree, label_dir):
                """Delete selected files"""
                selection = tree.selection()
                if not selection:
                    messagebox.showwarning("Warning", 
                                         "Please select files to delete")
                    return
                
                # Filter out group items
                files_to_delete = []
                for item in selection:
                    if 'file' in tree.item(item, 'tags'):
                        filename = tree.item(item)['values'][0]
                        if filename:
                            files_to_delete.append(filename)
                
                if not files_to_delete:
                    messagebox.showwarning("Warning", 
                                         "Please select files to delete")
                    return
                
                if not messagebox.askyesno(
                    "Confirm Delete",
                    f"Are you sure you want to delete these {len(files_to_delete)} file(s)?\n\n" +
                    "\n".join(files_to_delete)
                ):
                    return
                
                try:
                    # Delete files
                    for filename in files_to_delete:
                        filepath = os.path.join(label_dir, filename)
                        os.remove(filepath)
                    
                    # Remove items from tree
                    for item in selection:
                        if 'file' in tree.item(item, 'tags'):
                            tree.delete(item)
                    
                    # Remove empty groups
                    for item in tree.get_children():
                        if not tree.get_children(item):
                            tree.delete(item)
                    
                    # If no more duplicates, close dialog
                    if not tree.get_children():
                        dialog.destroy()
                    
                    # Refresh main file list
                    self.refresh_files()
                    
                    messagebox.showinfo("Success", 
                                      f"Successfully deleted {len(files_to_delete)} file(s)")
                    
                except Exception as e:
                    messagebox.showerror("Error", 
                                       f"Error deleting files: {str(e)}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error finding duplicates: {str(e)}")
        finally:
            self.show_progress(False)

    def setup_repository(self):
        """Setup local repository"""
        try:
            # Create directory in user's AppData/Local folder
            app_data = os.path.join(os.environ['LOCALAPPDATA'], 'LabelManager')
            repo_dir = os.path.join(app_data, 'Repository')
            
            # Create app directory if it doesn't exist
            if not os.path.exists(app_data):
                os.makedirs(app_data)
            
            # Remove existing repo if it exists
            if os.path.exists(repo_dir):
                try:
                    shutil.rmtree(repo_dir)
                except PermissionError:
                    # If can't remove, try to work with existing repo
                    self.local_repo_path = repo_dir
                    return True
            
            try:
                os.makedirs(repo_dir)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to create repository directory: {str(e)}")
                return False
            
            self.local_repo_path = repo_dir
            
            # Create labels directory if it doesn't exist
            labels_dir = os.path.join(self.local_repo_path, self.labels_path)
            if not os.path.exists(labels_dir):
                os.makedirs(labels_dir)
            
            return True
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to setup repository: {str(e)}")
            return False

    def show_debug_dialog(self, title, text):
        """Show a dialog with debug information"""
        debug_window = tk.Toplevel(self.root)
        debug_window.title(title)
        debug_window.geometry("600x400")
        
        # Add text widget
        text_widget = tk.Text(debug_window, wrap=tk.WORD, padx=10, pady=10)
        text_widget.pack(fill=tk.BOTH, expand=True)
        
        # Add scrollbar
        scrollbar = tk.Scrollbar(text_widget)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Configure scrollbar
        text_widget.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=text_widget.yview)
        
        # Insert text
        text_widget.insert(tk.END, text)
        text_widget.config(state=tk.DISABLED)
        
        # Add close button
        close_button = tk.Button(debug_window, text="Close", command=debug_window.destroy)
        close_button.pack(pady=10)

    def __del__(self):
        """Cleanup temporary repository"""
        if self.local_repo_path and os.path.exists(self.local_repo_path):
            try:
                shutil.rmtree(self.local_repo_path)
            except:
                pass

def main():
    root = tk.Tk()
    root.title("Label Manager")
    
    # Set style
    style = ttk.Style()
    style.theme_use('clam')  # or 'vista' on Windows
    
    app = GitHubLabelManager(root)
    root.mainloop()

if __name__ == "__main__":
    main()

from PIL import Image, ImageDraw, ImageFont
import barcode
from barcode.writer import ImageWriter
from dataclasses import dataclass
from typing import Optional, Tuple
import os

@dataclass
class LabelData:
    name_line1: str
    name_line2: str
    variant: str
    upc_code: str

class BarcodeGenerator:
    def __init__(self, settings):
        self.settings = settings
        self._setup_fonts()

    def _setup_fonts(self):
        """Setup font paths and sizes"""
        try:
            fonts_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "fonts")
            
            # Check if fonts directory exists
            if not os.path.exists(fonts_dir):
                raise FileNotFoundError("Fonts directory not found. Please make sure the 'fonts' directory exists with arial.ttf and arialbd.ttf")
            
            # Use Arial Bold for large text
            arial_bold_path = os.path.join(fonts_dir, "arialbd.ttf")
            if not os.path.exists(arial_bold_path):
                raise FileNotFoundError("arialbd.ttf not found in fonts directory")
            self.font_large = ImageFont.truetype(arial_bold_path, self.settings.font_size_large)
            
            # Use Regular Arial for medium text
            arial_path = os.path.join(fonts_dir, "arial.ttf")
            if not os.path.exists(arial_path):
                raise FileNotFoundError("arial.ttf not found in fonts directory")
            self.font_medium = ImageFont.truetype(arial_path, self.settings.font_size_medium)
            
        except Exception as e:
            print(f"Error setting up fonts: {e}")
            print("Using default font as fallback")
            self.font_large = ImageFont.load_default()
            self.font_medium = ImageFont.load_default()

    def generate_barcode_image(self, upc_code: str) -> Optional[Image.Image]:
        """Generate barcode image using python-barcode"""
        try:
            barcode_class = barcode.get_barcode_class('upc')
            barcode_writer = ImageWriter()
            barcode_writer.set_options({
                'module_height': 15.0,
                'module_width': 0.4,
                'quiet_zone': 8.0,
                'font_size': 10,
                'text_distance': 5
            })
            
            barcode_obj = barcode_class(upc_code, writer=barcode_writer)
            barcode_image = barcode_obj.render()
            
            return barcode_image
        except Exception as e:
            print(f"Error generating barcode: {e}")
            return None

    def generate_label(self, data: LabelData) -> Optional[Image.Image]:
        """Generate complete label with text and barcode"""
        try:
            # Create blank label
            label = Image.new('RGB', (self.settings.LABEL_WIDTH, self.settings.LABEL_HEIGHT), 'white')
            draw = ImageDraw.Draw(label)

            # Configure default colors
            text_color = (0, 0, 0)  # Black color for text
            
            # Draw text elements
            # Name Line 1 (fixed position at 20,20)
            if data.name_line1:
                draw.text((20, 20), data.name_line1, font=self.font_large, fill=text_color)
            
            # Name Line 2 (position depends on Name Line 1)
            if data.name_line2:
                name1_height = draw.textbbox((0, 0), data.name_line1 if data.name_line1 else "", font=self.font_large)[3]
                draw.text((20, 20 + name1_height), data.name_line2, font=self.font_large, fill=text_color)

            # Variant (fixed position at y=210)
            if data.variant:
                text_width = draw.textlength(data.variant, font=self.font_medium)
                x = (self.settings.LABEL_WIDTH - text_width) // 2
                draw.text((x, 210), data.variant, font=self.font_medium, fill=text_color)

            # Generate and paste barcode (fixed position at y=310)
            barcode_image = self.generate_barcode_image(data.upc_code)
            if barcode_image:
                # Resize barcode
                barcode_width = self.settings.barcode_width
                barcode_height = self.settings.barcode_height
                barcode_image = barcode_image.resize((barcode_width, barcode_height), Image.LANCZOS)

                # Center barcode horizontally at y=310
                x = (self.settings.LABEL_WIDTH - barcode_width) // 2
                label.paste(barcode_image, (x, 310))

            return label
        except Exception as e:
            print(f"Error generating label: {e}")
            return None

    def _add_text_to_label(self, draw: ImageDraw.ImageDraw, data: LabelData):
        """Add text elements to the label"""
        # Calculate text positions
        name1_pos = self._center_text(data.name_line1, self.font_large, self.settings.LABEL_WIDTH)
        name2_pos = self._center_text(data.name_line2, self.font_large, self.settings.LABEL_WIDTH)
        variant_pos = self._center_text(data.variant, self.font_medium, self.settings.LABEL_WIDTH)

        # Draw text
        draw.text((name1_pos, 20), data.name_line1, font=self.font_large, fill='black')
        draw.text((name2_pos, 80), data.name_line2, font=self.font_large, fill='black')
        draw.text((variant_pos, 140), data.variant, font=self.font_medium, fill='black')

    def _center_text(self, text: str, font: ImageFont.FreeTypeFont, width: int) -> int:
        """Calculate x position to center text"""
        text_width = font.getlength(text)
        return (width - text_width) // 2

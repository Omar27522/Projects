import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from typing import Optional, Dict, Any, Callable
import os
from PIL import Image, ImageTk
import pyautogui
from ..config import ConfigManager
from .window_manager import WindowManager
from ..barcode_generator import BarcodeGenerator, LabelData

class MainWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        
        self.config_manager = ConfigManager()
        self.window_manager = WindowManager()
        self.barcode_generator = BarcodeGenerator(self.config_manager.settings)
        
        self._setup_fonts()
        self._setup_variables()
        self._create_main_window()

    def _setup_fonts(self):
        """Configure default fonts"""
        self.default_font = ('TkDefaultFont', 11)
        self.button_font = ('TkDefaultFont', 11, 'normal')
        self.entry_font = ('TkDefaultFont', 11)
        self.label_font = ('TkDefaultFont', 11)
        self.view_files_font = ('TkDefaultFont', 12, 'bold')

        self.option_add('*Font', self.default_font)
        self.option_add('*Button*Font', self.button_font)
        self.option_add('*Entry*Font', self.entry_font)
        self.option_add('*Label*Font', self.label_font)

    def _setup_variables(self):
        """Initialize tkinter variables"""
        self.font_size_large = tk.IntVar(value=self.config_manager.settings.font_size_large)
        self.font_size_medium = tk.IntVar(value=self.config_manager.settings.font_size_medium)
        self.barcode_width = tk.IntVar(value=self.config_manager.settings.barcode_width)
        self.barcode_height = tk.IntVar(value=self.config_manager.settings.barcode_height)
        self.always_on_top = tk.BooleanVar(value=self.config_manager.settings.always_on_top)
        self.transparency_level = tk.DoubleVar(value=self.config_manager.settings.transparency_level)
        self.png_count = tk.StringVar(value=f"Labels: {self.config_manager.settings.label_counter}")

    def _create_main_window(self):
        """Create and setup the main application window"""
        # Configure main window
        self.title("Label Maker")
        
        # Center window on screen
        self.update_idletasks()
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        x = (screen_width - self.winfo_width()) // 2
        y = (screen_height - self.winfo_height()) // 2
        self.geometry(f"+{x}+{y}")
        
        # Prevent window resizing
        self.resizable(False, False)
        
        # Bind window close event
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        
        # Create main frame with comfortable padding
        self.main_frame = tk.Frame(self, padx=8, pady=5, bg='SystemButtonFace')
        self.main_frame.pack(expand=True, fill=tk.BOTH)
        
        # Create top control frame
        self._create_top_control_frame()
        
        # Create control buttons frame (Settings and Reset)
        self._create_control_frame()
        
        # Create input fields
        self._create_input_fields()
        
        # Create action buttons frame
        self._create_action_buttons()

    def _create_top_control_frame(self):
        """Create top control frame with Always on Top and Labels Count buttons"""
        top_control_frame = tk.Frame(self.main_frame, bg='SystemButtonFace')
        top_control_frame.grid(row=0, column=0, columnspan=2, sticky="ew", pady=3)
        
        # Always on top button
        self.always_on_top_btn = tk.Button(top_control_frame,
            text="Always On Top ",
            bg='#2ecc71' if self.always_on_top.get() else '#95a5a6',  # Bright green when active, gray when not
            activebackground='#27ae60',  # Darker green when clicked
            fg='white',
            relief='sunken' if self.always_on_top.get() else 'raised',
            width=15,
            command=self._toggle_always_on_top
        )
        self.always_on_top_btn.pack(side=tk.LEFT, padx=4)
        
        # Labels count button with vibrant blue theme
        self.png_count_btn = tk.Button(top_control_frame,
            textvariable=self.png_count,
            command=self._select_output_directory,
            fg='white',
            bg='#3498db',  # Bright blue
            activebackground='#2980b9',  # Darker blue when clicked
            width=10,
            font=('TkDefaultFont', 9, 'bold')
        )
        self.png_count_btn.pack(side=tk.LEFT, padx=4)

    def _create_control_frame(self):
        """Create control buttons frame (Settings and Reset)"""
        control_frame = tk.Frame(self.main_frame, bg='SystemButtonFace')
        control_frame.grid(row=1, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Settings button with vibrant blue theme
        settings_btn = tk.Button(control_frame,
            text="Settings",
            width=8,
            bg='#3498db',  # Bright blue
            activebackground='#2980b9',  # Darker blue when clicked
            fg='white',
            command=self.show_settings
        )
        settings_btn.pack(side=tk.LEFT, padx=5)
        
        # Reset button with vibrant red theme
        reset_btn = tk.Button(control_frame,
            text="Reset",
            width=8,
            bg='#e74c3c',  # Bright red
            activebackground='#c0392b',  # Darker red when clicked
            fg='white',
            command=self.clear_inputs
        )
        reset_btn.pack(side=tk.RIGHT, padx=5)

    def _create_input_fields(self):
        """Create input fields"""
        self.inputs = {}
        labels = [
            ("Product Name Line 1", "name_line1"),
            ("Line 2 (optional)", "name_line2"),
            ("Variant", "variant"),
            ("UPC Code (12 digits)", "upc_code")
        ]
        
        for idx, (label_text, key) in enumerate(labels):
            # Label
            label = tk.Label(self.main_frame,
                text=label_text,
                anchor="e",
                width=20,
                bg='SystemButtonFace'
            )
            label.grid(row=idx+2, column=0, padx=5, pady=3, sticky="e")
            
            # Entry
            entry = tk.Entry(self.main_frame,
                width=25,  # Increased from 15
                relief='sunken',
                bg='white'
            )
            
            # Add validation for UPC Code
            if key == "upc_code":
                entry.config(validate="key")
                entry.bind("<KeyRelease>", 
                          lambda e, ent=entry: ent.delete(12, tk.END) 
                          if len(ent.get()) > 12 else None)
            
            # Add context menu
            self._add_context_menu(entry)
            
            entry.grid(row=idx+2, column=1, padx=5, pady=3, sticky="w")
            self.inputs[key] = entry

    def _create_action_buttons(self):
        """Create action buttons frame"""
        button_frame = tk.Frame(self.main_frame, bg='SystemButtonFace')
        button_frame.grid(row=6, column=0, columnspan=2, pady=5)
        
        # Preview button with vibrant blue theme
        preview_btn = tk.Button(button_frame,
            text="Preview",
            width=10,
            bg='#3498db',  # Bright blue
            activebackground='#2980b9',  # Darker blue when clicked
            fg='white',
            command=self.preview_label
        )
        preview_btn.pack(side=tk.LEFT, padx=2)
        
        # Generate button with vibrant green theme
        generate_btn = tk.Button(button_frame,
            text="Generate",
            width=10,
            bg='#2ecc71',  # Bright green
            activebackground='#27ae60',  # Darker green when clicked
            fg='white',
            command=self.generate_label
        )
        generate_btn.pack(side=tk.LEFT, padx=2)
        
        # View Files button with vibrant purple theme
        view_files_btn = tk.Button(button_frame,
            text="View Files",
            width=10,
            bg='#9b59b6',  # Bright purple
            activebackground='#8e44ad',  # Darker purple when clicked
            fg='white',
            font=self.view_files_font,
            command=self.view_directory_files
        )
        view_files_btn.pack(side=tk.LEFT, padx=2)

    def _create_tooltip(self, widget, text):
        """Create a tooltip for a widget"""
        def enter(event):
            x, y, _, _ = widget.bbox("insert")
            x += widget.winfo_rootx() + 25
            y += widget.winfo_rooty() + 20
            
            # Creates a toplevel window
            self.tooltip = tk.Toplevel(widget)
            self.tooltip.wm_overrideredirect(True)
            self.tooltip.wm_geometry(f"+{x}+{y}")
            
            label = ttk.Label(self.tooltip, text=text, background="#ffffe0", relief='solid', borderwidth=1)
            label.pack()
            
        def leave(event):
            if hasattr(self, 'tooltip'):
                self.tooltip.destroy()
                
        widget.bind('<Enter>', enter)
        widget.bind('<Leave>', leave)

    def _add_context_menu(self, widget):
        """Add right-click context menu to widget"""
        menu = tk.Menu(widget, tearoff=0)
        menu.add_command(label="Copy", 
                        command=lambda: widget.event_generate('<<Copy>>'))
        menu.add_command(label="Paste", 
                        command=lambda: widget.event_generate('<<Paste>>'))
        menu.add_command(label="Cut", 
                        command=lambda: widget.event_generate('<<Cut>>'))
        menu.add_separator()
        menu.add_command(label="Select All", 
                        command=lambda: widget.select_range(0, tk.END))
        
        widget.bind("<Button-3>", 
                   lambda e: menu.tk_popup(e.x_root, e.y_root))

    def _toggle_always_on_top(self):
        """Toggle always on top state"""
        is_on_top = not self.always_on_top.get()
        self.always_on_top.set(is_on_top)
        
        # Update the button appearance
        self.always_on_top_btn.config(
            bg='#2ecc71' if is_on_top else '#95a5a6',  # Bright green when active, gray when not
            activebackground='#27ae60',  # Darker green when clicked
            relief='sunken' if is_on_top else 'raised'
        )
        
        # Update window state
        self.attributes('-topmost', is_on_top)
        self.config_manager.settings.always_on_top = is_on_top
        self.config_manager.save_settings()

    def _update_window_settings(self):
        """Update window settings based on current state"""
        self.window_manager.set_window_on_top(
            self, 
            self.always_on_top.get()
        )
        self.window_manager.make_draggable(self)

    def _update_png_count(self):
        """Update PNG count label"""
        if self.config_manager.settings.last_directory:
            count = len([f for f in os.listdir(self.config_manager.settings.last_directory)
                        if f.lower().endswith('.png')])
            self.config_manager.settings.label_counter = count
            self.png_count.set(f"Labels: {count}")
            self.config_manager.save_settings()

    def _select_output_directory(self):
        """Select output directory"""
        directory = filedialog.askdirectory()
        if directory:
            self.config_manager.settings.last_directory = directory
            self.config_manager.save_settings()
            self._update_png_count()

    def preview_label(self):
        """Show label preview"""
        label_data = self._get_label_data()
        if not label_data:
            return

        # If preview window exists and is valid, just focus it
        if hasattr(self, 'preview_window') and self.preview_window and self.preview_window.winfo_exists():
            self.window_manager.focus_window(self.preview_window)
            return

        label_image = self.barcode_generator.generate_label(label_data)
        if label_image:
            self.preview_window = self.window_manager.create_window("Label Preview")
            self.preview_window.is_preview_window = True
            
            # Resize for display
            display_img = label_image.resize(
                (self.config_manager.settings.LABEL_WIDTH // 2,
                 self.config_manager.settings.LABEL_HEIGHT // 2),
                Image.Resampling.LANCZOS
            )
            
            photo = ImageTk.PhotoImage(display_img)
            img_label = ttk.Label(self.preview_window, image=photo)
            img_label.image = photo  # Keep reference
            img_label.pack(padx=5, pady=5)

            # Create button frame
            button_frame = ttk.Frame(self.preview_window)
            button_frame.pack(pady=5)

            # Generate Label button with styling
            generate_btn = tk.Button(button_frame, 
                text="Generate Label",
                command=lambda: self.generate_label(),
                bg='#e3f2fd',   # Light blue background
                activebackground='#bbdefb',  # Slightly darker when clicked
                font=('TkDefaultFont', 9, 'bold'),
                relief='raised'
            )
            generate_btn.pack(side=tk.LEFT, padx=3)

            # Add hover effect
            def on_generate_enter(e):
                generate_btn['bg'] = '#bbdefb'
            def on_generate_leave(e):
                generate_btn['bg'] = '#e3f2fd'
            generate_btn.bind("<Enter>", on_generate_enter)
            generate_btn.bind("<Leave>", on_generate_leave)

            # Print Label button
            def print_label():
                try:
                    # Create a temporary file
                    temp_file = os.path.join(os.environ.get('TEMP', os.getcwd()), 
                                           f"temp_label_{label_data.upc_code}.png")
                    label_image.save(temp_file, dpi=(self.config_manager.settings.DPI,
                                                   self.config_manager.settings.DPI))
                    
                    # Open the file with the default image viewer/printer
                    os.startfile(temp_file, "print")
                    
                    # Wait a moment for the print dialog to appear and press Enter
                    self.preview_window.after(1000, lambda: pyautogui.press('enter'))
                    
                    # Schedule the temporary file for deletion after a delay
                    self.preview_window.after(5000, 
                        lambda: os.remove(temp_file) if os.path.exists(temp_file) else None)
                    
                    # Close the preview window
                    self.preview_window.destroy()
                    self.preview_window = None
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to print: {str(e)}")

            print_btn = tk.Button(button_frame,
                text="Print Label",
                command=print_label,
                bg='#e8f5e9',  # Light green background
                activebackground='#c8e6c9',  # Slightly darker when clicked
                font=('TkDefaultFont', 9, 'bold'),
                relief='raised'
            )
            print_btn.pack(side=tk.LEFT, padx=3)

            # Add hover effect
            def on_print_enter(e):
                print_btn['bg'] = '#c8e6c9'
            def on_print_leave(e):
                print_btn['bg'] = '#e8f5e9'
            print_btn.bind("<Enter>", on_print_enter)
            print_btn.bind("<Leave>", on_print_leave)

            # Set window properties
            self.window_manager.set_window_on_top(self.preview_window, self.always_on_top.get())
            self.window_manager.make_draggable(self.preview_window)

    def generate_label(self):
        """Generate and save label"""
        # Always ask for directory and update last_directory
        directory = filedialog.askdirectory(initialdir=self.config_manager.settings.last_directory)
        if not directory:
            return
            
        # Update and save the last used directory
        self.config_manager.settings.last_directory = directory
        self.config_manager.save_settings()

        label_data = self._get_label_data()
        if not label_data:
            return

        label_image = self.barcode_generator.generate_label(label_data)
        if label_image:
            filename = f"{label_data.upc_code}.png"
            filepath = os.path.join(directory, filename)
            label_image.save(filepath)
            messagebox.showinfo("Success", f"Label saved as {filename}")

    def show_settings(self):
        """Show settings window"""
        settings_window = self.window_manager.create_window("Settings")
        
        # Font size settings
        ttk.Label(settings_window, text="Large Font Size:").grid(row=0, column=0, padx=5, pady=2)
        ttk.Entry(settings_window, textvariable=self.font_size_large).grid(row=0, column=1, padx=5, pady=2)
        
        ttk.Label(settings_window, text="Medium Font Size:").grid(row=1, column=0, padx=5, pady=2)
        ttk.Entry(settings_window, textvariable=self.font_size_medium).grid(row=1, column=1, padx=5, pady=2)
        
        # Barcode size settings
        ttk.Label(settings_window, text="Barcode Width:").grid(row=2, column=0, padx=5, pady=2)
        ttk.Entry(settings_window, textvariable=self.barcode_width).grid(row=2, column=1, padx=5, pady=2)
        
        ttk.Label(settings_window, text="Barcode Height:").grid(row=3, column=0, padx=5, pady=2)
        ttk.Entry(settings_window, textvariable=self.barcode_height).grid(row=3, column=1, padx=5, pady=2)
        
        # Window settings
        ttk.Checkbutton(settings_window, text="Always on Top", 
                       variable=self.always_on_top).grid(row=4, column=0, columnspan=2, pady=5)
        
        # Save button
        ttk.Button(settings_window, text="Save", 
                  command=lambda: self._save_settings(settings_window)).grid(row=5, column=0, columnspan=2, pady=10)

    def _save_settings(self, settings_window):
        """Save settings and close settings window"""
        self.config_manager.settings.font_size_large = self.font_size_large.get()
        self.config_manager.settings.font_size_medium = self.font_size_medium.get()
        self.config_manager.settings.barcode_width = self.barcode_width.get()
        self.config_manager.settings.barcode_height = self.barcode_height.get()
        self.config_manager.settings.always_on_top = self.always_on_top.get()
        self.config_manager.settings.transparency_level = self.transparency_level.get()
        
        self.config_manager.save_settings()
        self.window_manager.set_window_on_top(self, self.always_on_top.get())
        settings_window.destroy()

    def _get_label_data(self) -> Optional[LabelData]:
        """Get label data from input fields"""
        upc = self.inputs["upc_code"].get().strip()
        if not upc:
            messagebox.showerror("Error", "UPC Code is required")
            return None

        return LabelData(
            name_line1=self.inputs["name_line1"].get().strip(),
            name_line2=self.inputs["name_line2"].get().strip(),
            variant=self.inputs["variant"].get().strip(),
            upc_code=upc
        )

    def clear_inputs(self):
        """Clear all input fields"""
        for entry in self.inputs.values():
            entry.delete(0, tk.END)

    def view_directory_files(self):
        """Display files from the output directory in a new window"""
        # If file window exists and is valid, just focus it
        if hasattr(self, 'file_window') and self.file_window and self.file_window.winfo_exists():
            self.window_manager.focus_window(self.file_window)
            return

        if not self.config_manager.settings.last_directory:
            messagebox.showerror("Warning", "Please select an output directory first.")
            return

        self.file_window = self.window_manager.create_window("View Files")
        self.file_window.minsize(450, 200)

        # Create main content frame
        main_content = tk.Frame(self.file_window)
        main_content.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        # Create top frame for controls
        top_frame = tk.Frame(main_content)
        top_frame.pack(fill=tk.X, padx=0, pady=1)

        # Add Pin (Always on Top) button
        window_always_on_top = tk.BooleanVar(value=False)
        window_top_btn = tk.Button(top_frame, text="Pin", bg='#C71585', relief='raised', width=8)

        def toggle_window_on_top():
            current_state = window_always_on_top.get()
            self.file_window.attributes('-topmost', current_state)
            if current_state:
                self.file_window.lift()
                window_top_btn.config(
                    text="Pin",
                    bg='#90EE90',  # Light green when active
                    relief='sunken'
                )
            else:
                window_top_btn.config(
                    text="Pin",
                    bg='#C71585',  # Velvet color when inactive
                    relief='raised'
                )

        window_top_btn.config(
            command=lambda: [window_always_on_top.set(not window_always_on_top.get()), 
                           toggle_window_on_top()]
        )
        window_top_btn.pack(side=tk.LEFT, padx=2)

        # Add Magnifier button
        is_magnified = tk.BooleanVar(value=False)
        magnifier_btn = tk.Button(top_frame, text="🔍", bg='#C71585', relief='raised', width=3,
                                font=('TkDefaultFont', 14))

        def toggle_magnification():
            current_state = is_magnified.get()
            new_size = 16 if current_state else 9
            listbox.configure(font=('TkDefaultFont', new_size))
            if current_state:
                h_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
                listbox.configure(wrap=tk.NONE)
            else:
                h_scrollbar.pack_forget()
                listbox.configure(wrap=tk.CHAR)
            magnifier_btn.config(
                bg='#90EE90' if current_state else '#C71585',
                relief='sunken' if current_state else 'raised'
            )

        magnifier_btn.config(
            command=lambda: [is_magnified.set(not is_magnified.get()), 
                           toggle_magnification()]
        )
        magnifier_btn.pack(side=tk.LEFT, padx=2)

        # Create search frame
        search_frame = tk.Frame(main_content)
        search_frame.pack(fill=tk.X, padx=0, pady=1)

        tk.Label(search_frame, text="Find:", 
                font=('TkDefaultFont', 9)).pack(side=tk.LEFT, padx=(2,0))
        search_var = tk.StringVar()
        search_entry = tk.Entry(search_frame, textvariable=search_var, 
                              font=('TkDefaultFont', 9))
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
        search_entry.focus_set()

        # Create list frame
        list_frame = tk.Frame(main_content)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=0, pady=1)

        # Add listbox with scrollbars
        listbox = tk.Listbox(list_frame, height=4, font=('TkDefaultFont', 9))
        listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        v_scrollbar = tk.Scrollbar(list_frame)
        v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        h_scrollbar = tk.Scrollbar(list_frame, orient=tk.HORIZONTAL)
        h_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)

        listbox.config(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        v_scrollbar.config(command=listbox.yview)
        h_scrollbar.config(command=listbox.xview)

        def update_file_list(*args):
            """Update the listbox based on search text"""
            search_text = search_var.get().lower()
            listbox.delete(0, tk.END)
            try:
                files = os.listdir(self.config_manager.settings.last_directory)
                png_files = [f for f in files if f.lower().endswith('.png')]
                for file in sorted(png_files):
                    if search_text in file.lower():
                        listbox.insert(tk.END, file)
                if len(png_files) == 0:
                    listbox.insert(tk.END, "No PNG files found")
                else:
                    listbox.selection_clear(0, tk.END)
                    listbox.selection_set(0)
                    listbox.see(0)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to read directory: {str(e)}")

        search_var.trace('w', update_file_list)

        # Initial file list update
        update_file_list()

        # Add double-click binding
        listbox.bind('<Double-Button-1>', lambda e: preview_selected_file())

        def open_selected_file():
            """Open the selected file"""
            selection = listbox.curselection()
            if selection:
                file_name = listbox.get(selection[0])
                file_path = os.path.join(self.config_manager.settings.last_directory, 
                                       file_name)
                try:
                    os.startfile(file_path)
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to open file: {str(e)}")

        def print_selected_file():
            """Print the selected file directly"""
            selection = listbox.curselection()
            if not selection:
                messagebox.showinfo("Info", "Please select a file to print.")
                return

            file_name = listbox.get(selection[0])
            file_path = os.path.join(self.config_manager.settings.last_directory, 
                                   file_name)
            try:
                os.startfile(file_path, "print")
                self.file_window.after(1000, lambda: pyautogui.press('enter'))
            except Exception as e:
                messagebox.showerror("Error", f"Failed to print: {str(e)}")

        def preview_selected_file():
            """Preview the selected image file"""
            selection = listbox.curselection()
            if not selection:
                messagebox.showinfo("Info", "Please select an image to preview.")
                return

            file_name = listbox.get(selection[0])
            file_path = os.path.join(self.config_manager.settings.last_directory, 
                                   file_name)

            try:
                img = Image.open(file_path)
                display_width = min(400, img.width)
                ratio = display_width / img.width
                display_height = int(img.height * ratio)

                img = img.resize((display_width, display_height), Image.Resampling.LANCZOS)
                img_tk = ImageTk.PhotoImage(img)

                preview_window = tk.Toplevel(self.file_window)
                preview_window.title(f"File Preview: {file_name}")
                preview_window.transient(self.file_window)

                # Create preview frame
                preview_frame = tk.Frame(preview_window)
                preview_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

                # Display image
                img_label = tk.Label(preview_frame, image=img_tk)
                img_label.image = img_tk
                img_label.pack(pady=5)

                # Add buttons
                button_frame = tk.Frame(preview_frame)
                button_frame.pack(pady=5)

                tk.Button(button_frame, text="Print", command=print_selected_file,
                         bg='#e8f5e9', activebackground='#c8e6c9',
                         font=('TkDefaultFont', 9, 'bold'),
                         relief='raised').pack(side=tk.LEFT, padx=3)

                tk.Button(button_frame, text="Open", command=open_selected_file,
                         bg='#e3f2fd', activebackground='#bbdefb',
                         font=('TkDefaultFont', 9, 'bold'),
                         relief='raised').pack(side=tk.LEFT, padx=3)

                # Make preview window draggable
                self.window_manager.make_draggable(preview_window)

            except Exception as e:
                messagebox.showerror("Error", f"Failed to preview image: {str(e)}")

        # Create bottom button frame
        button_frame = tk.Frame(main_content)
        button_frame.pack(fill=tk.X, padx=2, pady=2)

        # Add buttons with styling
        tk.Button(button_frame, text="Open", command=open_selected_file,
                 bg='#e3f2fd', activebackground='#bbdefb',
                 font=('TkDefaultFont', 9, 'bold'),
                 relief='raised',
                 width=15,
                 height=2
                ).pack(side=tk.LEFT, padx=2)

        tk.Button(button_frame, text="Print", command=print_selected_file,
                 bg='#e8f5e9', activebackground='#c8e6c9',
                 font=('TkDefaultFont', 9, 'bold'),
                 relief='raised',
                 width=15,
                 height=2
                ).pack(side=tk.LEFT, padx=2)

        tk.Button(button_frame, text="Preview", command=preview_selected_file,
                 bg='#fff3e0', activebackground='#ffe0b2',
                 font=('TkDefaultFont', 9, 'bold'),
                 relief='raised',
                 width=15,
                 height=2
                ).pack(side=tk.LEFT, padx=2)

        # Add GitHub icon button
        icon_data = '''
        iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAAWQAA
        AFkBqp2phgAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAJESURBVDiNjZO9a1NRHIaf
        c8+9N/feJM1HY5LaFquLiCAOUrDgJl1EdHERnMTVyUHBf8DBxck/wEEHFRRxEZQiDorFQYtLqkixTZrkJrk3
        997z8zChMWiwfqcDL7zP+z7wCq01/0dz0/Mm8AA4ChjAGvBU+8XjP+WJv4T3gGfABaD7R+gT8FAI7s5N5U78
        AUwDL4Bx4NnG9g7LGzUKhRJCCIyYzUgmSSadxPeaC8C1uancq7ZBAL4Cg0qp5M3Hz3j3YQnP8zF0AyklSimE
        gOFslkuTE0gpk8Bz4DJA5AD8CIwrpZLXHjxk4f0iYRjiui4t10UpRRiGrBaLvF5cpFqtWsCZdkVmG3wK9AMU
        SiXmF94ThCGO4+C6LkopjDCg5Hn4YYhpGGxvbZHP5zEMI92G9wAngI1qrY7neQRBgOM4eEFA0/exEZimSRRF
        KKXQWlOv1RgcHNwFjgJY7VYXgO+maeJ5Hq1WC9/3sUwTwzCwLAulFFpr6vU6WmtarRau6/4CHgI/hRDrgAaS
        pmXSbDYJggCpFEIIDAAhBEopGo0GWmvCMKRer4cxxnngE/DtYBfuCCFeaqUujwwPs7y6SqvVwhACKSVSSoQQ
        RFGE1hrHcUgYxjvgDHBXwN5h6gKuCMH9kydOMjY6yreNDba2t2k0m0RRhGmaJBIJkokEA5kMJ8bGsG0b4BZw
        HcgdTOEWcAe4CwwBCSB2kN0EVoA54DHw8WCkw0d0FrgKTAJZIAmsA/PAG+0XT/0bSjf5V5tNoNsAAAAASUVO
        RK5CYII=
        '''
        # Convert base64 icon to PhotoImage
        import base64
        from io import BytesIO
        from PIL import Image, ImageTk
        
        icon_data = base64.b64decode(icon_data.replace('\n', '').strip())
        image = Image.open(BytesIO(icon_data))
        github_icon = ImageTk.PhotoImage(image)

        tk.Button(button_frame, image=github_icon,
                 width=30,
                 height=30,
                 bg='#24292e',  # GitHub dark color
                 activebackground='#1b1f23',  # Darker shade for hover
                 command=self._open_github_manager
                ).pack(side=tk.RIGHT, padx=2)

    def _open_github_manager(self):
        """Open GitHub Label Manager window"""
        try:
            from src.github_label_manager import GitHubLabelManager
            if not hasattr(self, 'github_manager') or not tk.Toplevel.winfo_exists(self.github_manager):
                self.github_manager = GitHubLabelManager(self)
                self.github_manager.focus_force()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open GitHub Label Manager: {str(e)}")

    def on_close(self):
        """Handle window close event"""
        self.config_manager.save_settings()
        self.quit()

    def run(self):
        """Start the application"""
        try:
            self.mainloop()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to start application: {str(e)}")
            raise
